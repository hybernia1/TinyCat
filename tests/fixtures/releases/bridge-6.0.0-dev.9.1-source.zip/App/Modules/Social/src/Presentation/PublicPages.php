<?php
declare(strict_types=1);

namespace TinyCat\Social\Presentation;

use TinyCat\Http\Request;
use TinyCat\Http\Response;
use TinyCat\Social\Posts\Resource as Posts;
use TinyCat\Support\Components;
use TinyCat\Support\Localization;
use TinyCat\Social\Profiles\Resource as Users;

/** Shared public page resources and SSR composition; APIs contain no markup. */
final class PublicPages
{
    /** @return array<string, mixed> */
    public static function find(string $path): array
    {
        if (\TinyCat\Http\LocaleRouting::split($path)['locale'] !== null) { $path = \TinyCat\Http\LocaleRouting::prepare($path); \TinyCat\Http\LocaleRouting::apply(); }
        $kind = ''; $data = null;
        if ($path === '/social' || ($path === '/' && \TinyCat\Social\Posts\Feed::homePath() === '/')) { $kind = 'home'; $data = \TinyCat\Social\Posts\Pages::homeData(); }
        elseif ($path === '/search') { $kind = 'search'; $data = \TinyCat\Social\Search\Pages::data(); }
        elseif (preg_match('~^/status/([1-9][0-9]*)$~D', $path, $match)) { $kind = 'status'; $data = \TinyCat\Social\Posts\Pages::detailData((int) $match[1]); }
        elseif (preg_match('~^/author/([1-9][0-9]*)$~D', $path, $match)) { $kind = 'author'; $data = \TinyCat\Social\Profiles\Pages::authorData((int) $match[1]); }
        elseif (preg_match('~^/tag/([^/]+)$~D', $path, $match)) { $kind = 'tag'; $data = \TinyCat\Social\Posts\Pages::tagData($match[1]); }
        if ($data === null) { Response::error(Localization::t('public.not_found_title'), 404, 'not_found'); }
        header('Cache-Control: no-store, private');
        return self::resource($kind, $data);
    }

    /** @param array<string, mixed> $data */
    public static function render(string $kind, array $data): void
    {
        $resource = self::resource($kind, $data);
        Layout::render($data['page'], Components::render('site/public-page', $resource + ['csrf' => \TinyCat\Core\Security\Csrf::token()]));
    }

    /** @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public static function resource(string $kind, array $data): array
    {
        $context = $data['context']; $page = $data['page']; $meta = $page['meta'];
        $viewer = $context['authUser'] ?? null;
        $home = $context['publicHomeFeedData'] ?? [];
        $items = $context['statusItems'] ?? $home['items'] ?? [];
        $more = $context['feedMore'] ?? $home['feed_more'] ?? [];
        $author = $context['author'] ?? null;
        $feedId = $context['feedId'] ?? $home['feed_id'] ?? ($kind === 'author' ? 'status-feed-author-' . (int) ($author['id'] ?? 0) : 'status-feed-tag-' . \TinyCat\Support\Text::slug((string) ($context['tag'] ?? '')));
        $editor = $context['editor'] ?? [];
        $url = $kind === 'home' ? (string) ($home['current_feed_url'] ?? '/') : (string) $meta['url'] . (!empty($context['compact']) ? '?compact=1' : '');
        $item = $context['item'] ?? null;
        $archiveType = (string) ($context['archiveType'] ?? '');
        $archiveOptions = [];
        if (in_array($kind, ['home', 'tag', 'author', 'search'], true)) {
            if (in_array($kind, ['tag', 'author'], true) && $archiveType !== '') { $url .= '?media=' . rawurlencode($archiveType); }
            $filterBase = $kind === 'home' && ($context['feed'] ?? '') === 'following' ? \TinyCat\Social\Posts\Feed::homePath() . '?feed=following' : (string) ($context['archiveBaseUrl'] ?? $page['current']);
            foreach (['' => 'all', 'images' => 'images', 'video' => 'video', 'audio' => 'audio', 'links' => 'links', 'text' => 'text'] as $type => $label) {
                $archiveOptions[] = ['url' => \TinyCat\Http\LocaleRouting::url($filterBase . ($type !== '' ? (str_contains($filterBase, '?') ? '&' : '?') . 'media=' . $type : '')),
                    'type' => $label, 'active' => $type === $archiveType];
            }
        }
        return [
            'version' => \TinyCat\Support\Version::CURRENT, 'kind' => $kind, 'url' => \TinyCat\Http\LocaleRouting::url($url), 'locale' => Localization::locale(), 'viewer' => $viewer !== null ? Users::profile($viewer) : null,
            'document' => \TinyCat\Core\Ui\Metadata::document($page),
            'tag' => (string) ($context['tag'] ?? ''), 'compact' => (bool) ($context['compact'] ?? false),
            'feed' => (string) ($context['feed'] ?? 'all'), 'feed_id' => $feedId,
            'login_required' => (bool) ($home['following_login_required'] ?? false),
            'items' => Posts::posts($items, $viewer),
            'item' => $item !== null ? Posts::post($item, $viewer) : null,
            'comments' => Posts::comments($context['comments'] ?? [], $viewer),
            'next_url' => (int) ($more['loaded'] ?? 0) >= (int) ($more['limit'] ?? 1) ? (string) ($more['next_url'] ?? '') : '',
            'sidebar_url' => '/api/site/sidebar' . (!empty($context['tag']) ? '?tag=' . rawurlencode($context['tag']) : ''),
            'sidebar' => in_array($kind, ['home', 'tag', 'status', 'search'], true) && empty($context['compact']),
            'author' => $author !== null ? Users::profile($author) : null,
            'bio' => (string) ($context['bio'] ?? ''), 'member_since' => !empty($context['memberSince']) ? \TinyCat\Support\Dates::dateIso($context['memberSince']) : '',
            'follow_counts' => $context['followCounts'] ?? [], 'activity' => $context['activityStats'] ?? [],
            'can_edit' => (bool) ($context['canEditProfile'] ?? false), 'can_follow' => (bool) ($context['canFollow'] ?? false), 'following' => (bool) ($context['isFollowing'] ?? false),
            'muted_until' => (($context['canSeeMute'] ?? false) || ($context['userIsMuted'] ?? false)) ? (string) ($context['mutedUntil'] ?? $context['userMutedUntil'] ?? '') : '',
            'composer' => $viewer !== null && empty($context['userIsMuted']) && ($kind === 'home' || (!empty($context['canPost']) && empty($context['mutedUntil']))),
            'viewer_profile_id' => $viewer !== null ? \TinyCat\Social\Profiles\Profiles::author_profile_edit_modal_id((int) $viewer['id']) : '',
            'viewer_profile_url' => $viewer !== null ? \TinyCat\Social\Profiles\Profiles::author_profile_edit_modal_url((int) $viewer['id'], 'email') : '',
            'email_missing' => $viewer !== null && trim((string) ($viewer['email'] ?? '')) === '',
            'images_enabled' => (bool) ($editor['image']['enabled'] ?? false),
            'profile_edit_url' => (string) ($context['authorProfileEditModalUrl'] ?? ''), 'profile_edit_id' => (string) ($context['authorProfileEditModalId'] ?? ''),
            'avatar_edit_url' => (string) ($context['authorAvatarEditModalUrl'] ?? ''), 'avatar_edit_id' => (string) ($context['authorAvatarEditModalId'] ?? ''),
            'following_url' => (string) ($context['authorFollowingModalUrl'] ?? ''), 'following_id' => (string) ($context['authorFollowingModalId'] ?? ''),
            'all_feed_url' => \TinyCat\Http\LocaleRouting::url(\TinyCat\Social\Posts\Feed::homePath() . ($archiveType !== '' ? '?media=' . $archiveType : '')),
            'following_feed_url' => \TinyCat\Http\LocaleRouting::url(\TinyCat\Social\Posts\Feed::homePath() . '?feed=following' . ($archiveType !== '' ? '&media=' . $archiveType : '')),
            'clear_filter_url' => \TinyCat\Http\LocaleRouting::url($kind === 'home' && ($context['feed'] ?? '') === 'following' ? \TinyCat\Social\Posts\Feed::homePath() . '?feed=following' : (string) ($context['archiveBaseUrl'] ?? $page['current'])),
            'archive_options' => $archiveOptions,
            'archive_type' => $archiveType,
            'rss_url' => (string) ($context['authorFeedUrl'] ?? $context['tagFeedUrl'] ?? $context['searchFeedUrl'] ?? ''),
            'login_url' => \TinyCat\Core\Identity\Login::auth_url_with_next('/login', $url),
            'login_modal_url' => \TinyCat\Core\Identity\Login::auth_modal_url('login', $url),
        ] + ($kind === 'search' ? ['search' => $context['search']] : []);
    }
}
