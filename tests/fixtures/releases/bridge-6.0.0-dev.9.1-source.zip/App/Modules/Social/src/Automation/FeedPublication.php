<?php
declare(strict_types=1);
namespace TinyCat\Social\Automation;

use TinyCat\Core\Publishing\FeedEntry;
use TinyCat\Core\Publishing\FeedImport;
use TinyCat\Core\Publishing\FeedTarget;
use TinyCat\Core\Publishing\PostCreation;

final class FeedPublication implements FeedTarget
{
    public function prepare(array $source, array $item): FeedEntry
    {
        $draft = PostCreation::fromText(FeedImport::renderPost($source, $item));
        return new FeedEntry($draft, $draft->links);
    }

    public function publish(array $source, FeedEntry $entry, array $links, ?array $image, string $publishedAt): int
    {
        return PostCreation::create((int) $source['bot_user_id'], $entry->draft, $links, $image, publishedAt: $publishedAt);
    }
}
