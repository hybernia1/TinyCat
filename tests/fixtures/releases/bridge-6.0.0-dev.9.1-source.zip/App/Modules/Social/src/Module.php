<?php
declare(strict_types=1);
namespace TinyCat\Social;

use TinyCat\Core\Modules\Contributions;
use TinyCat\Core\Modules\ModuleSchema;
use TinyCat\Core\Modules\Registries;
use TinyCat\Http\Api;

/** The complete social application: one activation, one resource owner, one initialization. */
final class Module implements \TinyCat\Core\Modules\StorageModule, \TinyCat\Core\Modules\ProvidesManagedSchemas, \TinyCat\Core\Modules\ProvidesContributions, \TinyCat\Core\Runtime\InitializesModule, \TinyCat\Core\Identity\ProvidesLifecycle
{
    public static function initialize(): void
    {
        Profiles\Registration::initialize();
        Posts\Registration::initialize();
        Moderation\ActionPolicy::register();
        Presentation\Registration::initialize();
    }

    public static function contributions(): Contributions
    {
        return (new Registries([
            'profiles' => Profiles\Registration::contributions(),
            'posts' => Posts\Registration::contributions(),
            'automation' => Automation\Registration::contributions(),
            'moderation' => Moderation\Registration::contributions(),
            'search' => Search\Registration::contributions(),
            'presentation' => Presentation\Registration::contributions(),
        ]))->entries;
    }

    /** @return array<string, ModuleSchema> */
    public static function schemas(): array
    {
        return [
            'tinycat.users' => Profiles\Schema::schema(),
            'tinycat.moderation' => Moderation\Schema::schema(),
            'tinycat.bots' => Automation\Schema::schema(),
        ];
    }

    /** @return list<string> */
    public static function tables(): array
    {
        return [...Profiles\Registration::tables(), ...Posts\Registration::tables(), ...Moderation\Registration::tables(), ...Automation\Registration::tables()];
    }

    public static function accountLifecycle(): \TinyCat\Core\Identity\Participant { return new \TinyCat\Core\Identity\Participant(prepareDelete: Posts\NotificationCleanup::prepareAccountDelete(...), statusChanged: Automation\Registration::accountLifecycle()->statusChanged); }

    public static function register(Api $api): void
    {
        Profiles\Registration::register($api);
        Posts\Registration::register($api);
        Moderation\Registration::register($api);
        Automation\Registration::register($api);
        Presentation\Registration::register($api);
        Search\Registration::register($api);
    }
}
