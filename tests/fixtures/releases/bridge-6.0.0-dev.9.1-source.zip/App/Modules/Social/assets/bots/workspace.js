import "../../../../../assets/ui/content-updates.js";
import "../../../../../assets/ui/list-navigation.js";
import "../../../../../assets/core/dom.js";
import "../../../../../assets/core/api-client.js";
import "../../../../../assets/ui/component-builders.js";
import "../../../../../assets/ui/tabs.js";
(function () {
  "use strict";
  var T = window.TinyCat, U = T.ui, e = T.dom.element, states = new WeakMap();
  function owner() { return document.querySelector("[data-bot-workspace-id]"); }
  function request(state, url) {
    var controller = new AbortController();
    state.requests.add(controller);
    return T.api.request(url, { signal: controller.signal }).finally(function () { state.requests.delete(controller); });
  }
  function failed(error) { if (error.name !== "AbortError") { T.toasts.show(error.message, "danger"); } }
  function metadata(state, data) {
    var values = { sources: data.item.source_count, active_sources: data.item.active_source_count, posts: data.item.post_count, runs: data.item.run_count };
    var cards = document.createDocumentFragment();
    Object.keys(values).forEach(function (key) { cards.appendChild(T.components.render("bots/stat", { stat: { key: key, value: values[key] } })); });
    T.content.replaceChildren(state.summary, cards);
    T.content.replaceChildren(state.status, T.components.render("ui/account-status", { status: data.item.status, label: U.text("users.statuses." + data.item.status) }));
  }
  function refreshMetadata(state) {
    var serial = state.metadataRevision = (state.metadataRevision || 0) + 1;
    return request(state, "/api/bots/accounts/" + state.id).then(function (response) {
      if (state.dialog.isConnected && state.metadataRevision === serial) { metadata(state, response.data); }
    }).catch(function (error) { if (state.dialog.isConnected && state.metadataRevision === serial) { failed(error); } });
  }
  function footer(state) {
    var content = state.active === "account" ? state.actions : state.pagers[state.active];
    Array.from(state.footer.children).forEach(function (node) { if (node !== content && node !== state.actions) { T.lifecycle.dispose(node); } });
    state.footer.replaceChildren();
    if (content) { state.footer.appendChild(content); }
    state.footer.hidden = !content;
  }
  function pagination(root, source) {
    var dialog = owner(), state = dialog && states.get(dialog);
    if (!state) { return; }
    var name = root === state.sources ? "sources" : root === state.posts ? "posts" : root === state.history ? "history" : null;
    if (!name) { return; }
    var pager = root.querySelector(".pagination");
    if (pager) { pager.remove(); }
    state.pagers[name] = pager;
    if (state.active !== name) { return; }
    footer(state);
    if (source && source.closest && source.closest(".pagination")) {
      state.dialog.querySelector(".modal-body").scrollTop = 0;
    }
  }
  function scopedSources(state, response, source) {
    var data = Object.assign({}, response.data, { pagination: U.pagination(response), scoped: true, list_target: "#bot-detail-sources-list" });
    Object.values(data.sorting || {}).forEach(function (heading) { heading.target = data.list_target; heading.history = false; });
    var navigation = data.navigation || {};
    [navigation.previous, navigation.next].concat(navigation.pages || []).forEach(function (link) { if (link) { link.history_url = false; } });
    state.sources.dataset.listUrl = "/api/bots/sources?" + new URLSearchParams(Object.assign({}, data.filters, { bot: state.id, page: data.pagination.page || 1, per_page: data.pagination.per_page }));
    T.bots.sources(state.sources, data);
    state.sources.dataset.loaded = "true";
    pagination(state.sources, source);
  }
  function scopedRuns(state, response, source) {
    var data = Object.assign({}, response.data, { pagination: U.pagination(response) });
    state.history.dataset.listUrl = data.url;
    T.content.replaceChildren(state.history, T.components.render("bots/runs-list", data));
    state.history.dataset.loaded = "true";
    pagination(state.history, source);
    var form = T.components.render("bots/run-filter-form", data);
    form.querySelectorAll("input, select").forEach(function (field) {
      field.defaultValue = field.value;
      if (field.options) { Array.from(field.options).forEach(function (option) { option.defaultSelected = option.selected; }); }
    });
    U.filterPanel(data.filter_modal, form);
  }
  function load(state, name, force) {
    var root = name === "sources" ? state.sources : name === "posts" ? state.posts : name === "history" ? state.history : null;
    if (!root || root.dataset.loading === "true" || root.dataset.loaded === "true" && !force) { return; }
    root.dataset.loading = "true"; root.setAttribute("aria-busy", "true");
    var url = name === "posts" ? root.dataset.botPostsUrl : root.dataset.listUrl, generation = root.dataset.apiGeneration;
    request(state, url).then(function (response) {
      if (!state.dialog.isConnected || generation !== root.dataset.apiGeneration || url !== (name === "posts" ? root.dataset.botPostsUrl : root.dataset.listUrl)) { return; }
      if (name === "sources") { scopedSources(state, response); }
      else if (name === "history") { scopedRuns(state, response); }
      else { T.bots.posts(root, response); root.dataset.loaded = "true"; }
      T.lifecycle.hydrate(root);
    }).catch(function (error) {
      if (error.name !== "AbortError" && state.dialog.isConnected && generation === root.dataset.apiGeneration && url === (name === "posts" ? root.dataset.botPostsUrl : root.dataset.listUrl)) {
        var retry = U.button("common.refresh");
        retry.addEventListener("click", function () { load(state, name, true); });
        T.content.replaceChildren(root, retry); delete state.pagers[name];
        if (state.active === name) { footer(state); }
        failed(error);
      }
    }).finally(function () { delete root.dataset.loading; root.removeAttribute("aria-busy"); });
  }
  function background() {
    ["#bot-accounts-list", "#bots-list", "#bot-queue-list"].forEach(function (selector) {
      var root = document.querySelector(selector);
      if (root) { T.lists.refresh(root); }
    });
  }
  function postUrl(id, query) {
    var params = new URLSearchParams();
    ["q", "source", "publication", "sort", "direction", "page", "per_page"].forEach(function (key) { if (query.has(key)) { params.set(key, query.get(key)); } });
    params.set("scope", "modal");
    return "/api/bots/accounts/" + id + "/posts?" + params;
  }
  T.botDetail = {
    modal: function (url, response, id) {
      var data = response.data, botId = Number(data.item.id);
      var form = U.form("/api/bots/accounts/" + botId, "PATCH");
      form.dataset.ajaxTarget = "#bot-detail-account";
      var fields = T.components.render("bots/account-fields", data);
      form.appendChild(fields);
      form.appendChild(U.button("common.save", { type: "submit", "class": "btn btn-primary" }));
      var dialog = U.adminDialog(id, data.item.username, form);
      dialog.dataset.botWorkspaceId = String(botId);
      var content = e("div", { "class": "stack stack-gap-16" });
      var status = U.accountDialogTitle(dialog, data.item);
      var summary = e("div", { "class": "grid sm:grid-2 md:grid-4" });
      var sources = e("div", { id: "bot-detail-sources-list", "class": "stack" });
      var posts = e("div", { id: "bot-detail-posts-list", "class": "stack" });
      sources.dataset.listUrl = "/api/bots/sources?bot=" + botId;
      posts.dataset.botPostsUrl = postUrl(botId, url.searchParams);
      var history = e("div", { id: "bot-detail-runs-list", "class": "stack" });
      history.dataset.listUrl = "/api/bots/accounts/" + botId + "/runs";
      var initial = url.searchParams.get("tab") || (url.searchParams.has("source") || url.searchParams.has("publication") || url.searchParams.has("q") ? "posts" : "account");
      var layout = U.tabbedContent(id, [
        { name: "account", label: "bots.detail_account", icon: "settings" },
        { name: "sources", label: "bots.detail_sources", icon: "rss" },
        { name: "history", label: "bots.detail_history", icon: "clock" },
        { name: "posts", label: "bots.detail_posts", icon: "file" }
      ], initial, data.item.username);
      initial = layout.initial;
      var panels = layout.panels, tabButtons = layout.buttons;
      content.appendChild(layout.content);
      panels.account.id = "bot-detail-account";
      tabButtons.account.setAttribute("aria-controls", panels.account.id);
      panels.account.append(summary, form); panels.sources.appendChild(sources); panels.history.appendChild(history); panels.posts.appendChild(posts);
      dialog.querySelector(".modal-body").replaceChildren(content);
      var state = { id: botId, dialog: dialog, sources: sources, posts: posts, history: history, summary: summary, status: status, active: initial, footer: dialog.querySelector(".modal-footer"), actions: dialog.querySelector(".modal-editor-actions"), pagers: {}, requests: new Set(), changed: false };
      states.set(dialog, state); metadata(state, data);
      var tabRoot = U.pinDialogTabs(dialog, layout.content);
      footer(state);
      tabRoot.addEventListener("tinycat:tab", function (event) { state.active = event.detail.name; footer(state); load(state, event.detail.name); });
      content.addEventListener("click", function (event) {
        var link = event.target.closest && event.target.closest("a[href]");
        if (!link) { return; }
        var target = new URL(link.getAttribute("href"), window.location.href);
        if (target.pathname !== "/admin/bots/" + botId) { return; }
        event.preventDefault(); event.stopPropagation();
        if (!target.search) { T.tabs.activate(tabButtons.account, true); return; }
        posts.dataset.botPostsUrl = postUrl(botId, target.searchParams); delete posts.dataset.loaded;
        T.tabs.activate(tabButtons.posts, true);
      });
      dialog.addEventListener("tinycat:success", function (event) {
        var source = event.target;
        var method = (source.dataset.apiMethod || source.dataset.method || source.getAttribute("method") || "GET").toUpperCase();
        if (method !== "GET") state.changed = true;
      });
      dialog.addEventListener("tinycat:modal-close", function () { T.botDetail.dispose(dialog); if (state.changed) background(); });
      // Hydration normally activates the selected tab; this also covers direct callers.
      dialog.addEventListener("tinycat:modal-open", function () { load(state, initial); });
      return dialog;
    },
    changed: function () { var dialog = owner(), state = dialog && states.get(dialog); if (state) state.changed = true; },
    result: function (source, response, target) {
      var dialog = owner(), state = dialog && states.get(dialog);
      if (!state || !target || !["bot-detail-account", "bot-detail-sources-list", "bot-detail-runs-list"].includes(target.id)) { return false; }
      var method = (source.dataset.apiMethod || source.dataset.method || source.getAttribute("method") || "GET").toUpperCase();
      if (method !== "GET") state.changed = true;
      if (target === state.history && method === "GET") { scopedRuns(state, response, source); return [target]; }
      else if (target === state.sources && method === "GET") { scopedSources(state, response, source); return [target]; }
      else {
        refreshMetadata(state);
        if (target === state.sources || state.sources.dataset.loaded === "true") { load(state, "sources", true); }
        if (state.posts.dataset.loaded === "true") { load(state, "posts", true); }
        if (state.history.dataset.loaded === "true") { load(state, "history", true); }
      }
      return [];
    },
    pagination: pagination,
    dispose: function (root) {
      var state = states.get(root);
      if (!state) { return; }
      state.requests.forEach(function (controller) { controller.abort(); });
      T.filters.remove("bot-detail-posts-filter-modal");
      T.filters.remove("bot-detail-runs-filter-modal");
      states.delete(root);
    },
    hydrate: function (root) {
      Array.from((root || document).querySelectorAll("[data-bot-detail-open]")).forEach(function (marker) {
        if (marker.dataset.ready === "true") { return; }
        marker.dataset.ready = "true";
        var id = Number(marker.dataset.botDetailOpen), query = new URLSearchParams(marker.dataset.botDetailQuery || "");
        query.delete("view");
        query.set("panel", "detail");
        var url = new URL("/api/bots/accounts/" + id + "?" + query, window.location.href);
        T.dialog.openResource("bot-detail-modal", url.pathname + url.search, {
          baseUrl: "/admin/bots/accounts", current: function () { return marker.isConnected; }
        }).catch(failed);
      });
    }
  };
}());
