import "../../../../Core/Publishing/assets/comments.js";
import "./controller.js";
window.TinyCat.status.controllers.comments = window.TinyCat.publishing.controllers.comments;
