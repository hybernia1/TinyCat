<?php
declare(strict_types=1);
namespace TinyCat\Blog;

use TinyCat\Core\Publishing\FeedEntry;
use TinyCat\Core\Publishing\FeedTarget;
use TinyCat\Core\Text\LinkParser;
use TinyCat\Core\Publishing\Links;
use TinyCat\Core\Publishing\PostCreation;
use TinyCat\Database\Connection;

final class FeedPublication implements FeedTarget
{
    public function prepare(array $source, array $item): FeedEntry
    {
        $title = trim((string) ($item['title'] ?? ''));
        $body = trim((string) ($item['content'] ?? $item['description'] ?? ''));
        $url = trim((string) ($item['url'] ?? ''));
        if ($url !== '' && !str_contains($body, $url)) { $body .= ($body !== '' ? "\n\n" : '') . $url; }
        $draft = PostCreation::fromText($body, 'article');
        $rejection = null;
        try { Articles::validateText($title, $body); }
        catch (\InvalidArgumentException) { $rejection = ['code' => 'article_invalid', 'params' => []]; }
        $links = Links::status_links_from_text($body);
        $origin = LinkParser::fromRaw($url);
        // Retain the external identity even when a long article has many earlier links.
        if ($origin !== null) { $links = [$origin, ...array_filter($links, static fn (array $link): bool => $link['url_hash'] !== $origin['url_hash'])]; }
        return new FeedEntry($draft, array_slice($links, 0, 3), compact('title', 'body'), $rejection);
    }

    public function publish(array $source, FeedEntry $entry, array $links, ?array $image, string $publishedAt): int
    {
        $id = PostCreation::create((int) $source['author_id'], $entry->draft, $links, $image, publishedAt: $publishedAt, kind: 'article');
        Connection::insert('blog_articles', ['content_id' => $id, 'title' => (string) $entry->data['title'], 'body' => (string) $entry->data['body']]);
        Connection::update('content', ['status' => (string) $source['publication_status']], ['id' => $id]);
        return $id;
    }
}
