<?php
declare(strict_types=1);
namespace TinyCat\Blog;

final class Schema
{
    public static function install(\PDO $pdo): void
    {
        $install = require dirname(__DIR__) . '/migrations/001-articles.php';
        $install($pdo);
        $upgrade = require dirname(__DIR__) . '/migrations/002-kinds.php'; $upgrade($pdo);
        $feeds = require dirname(__DIR__) . '/migrations/003-feed-sources.php'; $feeds($pdo);
    }
}
