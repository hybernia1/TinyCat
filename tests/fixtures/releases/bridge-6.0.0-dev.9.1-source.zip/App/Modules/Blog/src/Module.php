<?php
declare(strict_types=1);
namespace TinyCat\Blog;

final class Module implements \TinyCat\Core\Modules\Module, \TinyCat\Core\Modules\ProvidesSchema, \TinyCat\Core\Modules\ProvidesContributions, \TinyCat\Core\Runtime\InitializesModule
{
    public static function initialize(): void
    {
        Discussion::initialize();
        \TinyCat\Core\Publishing\Integration::provide('tinycat.blog', 'article', new \TinyCat\Core\Publishing\TextPolicy(outbound: static fn (int $id, string $hash, int $comment): string => '/api/articles/' . $id . '/links/' . $hash . '?navigate=1'));
    }

    public static function contributions(): \TinyCat\Core\Modules\Contributions
    {
        return new \TinyCat\Core\Modules\Contributions(tasks: [FeedSources::task()], embeds: [new \TinyCat\Core\Modules\EmbedSource('blog.articles', Exports::embed(...), 20)], sitemaps: [new \TinyCat\Core\Modules\SitemapSection('articles', SitemapData::count(...), SitemapData::entries(...), 50)], search: [SearchData::source()], homepages: [new \TinyCat\Core\Modules\EntryPage('tinycat.blog.home', '/blog', static function (): void { Pages::listing(); }, 20, static fn (): string => \TinyCat\Support\Localization::t('blog.articles'))], dashboards: [new \TinyCat\Core\Modules\EntryPage('tinycat.blog.admin', '/admin/articles', static function (): void { Pages::listing(false); }, 20)], localizedRoutes: [new \TinyCat\Core\Modules\LocalizedRoute('blog.archive', '^/blog$', ['before', 'at']), new \TinyCat\Core\Modules\LocalizedRoute('blog.article', '^/articles/[1-9][0-9]*$')], navigation: [
            new \TinyCat\Core\Modules\NavigationItem('tinycat.blog.articles', static fn (): array => ['href' => '/admin/articles', 'icon' => 'file-text', 'label' => \TinyCat\Support\Localization::t('blog.articles')], 25),
            new \TinyCat\Core\Modules\NavigationItem('tinycat.blog.sources', static fn (): array => ['href' => '/admin/article-sources', 'icon' => 'rss', 'label' => \TinyCat\Support\Localization::t('blog.feeds.title')], 26),
        ]);
    }

    public static function schema(): \TinyCat\Core\Modules\ModuleSchema
    {
        return new \TinyCat\Core\Modules\ModuleSchema(3, ['blog_articles', 'blog_sources', 'blog_feed_history', 'blog_source_articles'], Schema::install(...), [
            new \TinyCat\Core\Modules\SchemaMigration(1, 'tinycat.blog.articles', dirname(__DIR__) . '/migrations/001-articles.php'),
            new \TinyCat\Core\Modules\SchemaMigration(2, 'tinycat.blog.kinds', dirname(__DIR__) . '/migrations/002-kinds.php'),
            new \TinyCat\Core\Modules\SchemaMigration(3, 'tinycat.blog.feeds', dirname(__DIR__) . '/migrations/003-feed-sources.php'),
        ]);
    }

    public static function register(\TinyCat\Http\Api $api): void
    {
        $ready = static fn (): bool => \TinyCat\Database\ModuleSchemas::ready(\TinyCat\Database\Connection::get(), ['tinycat.blog' => self::schema()]);
        Api::register($api->whenReady($ready));
        \TinyCat\Http\Router::route('GET', '/admin/article-sources', FeedAdministration::page(...));
        \TinyCat\Http\Router::route(['GET', 'HEAD'], '/blog/feed', Exports::feed(...), 'application/rss+xml');
        \TinyCat\Http\Router::route(['GET', 'HEAD'], '/blog', Pages::listing(...));
        \TinyCat\Http\Router::route('GET', '/admin/articles', static fn () => Pages::listing(false));
        \TinyCat\Http\Router::route(['GET', 'HEAD'], '/articles/{id:[1-9][0-9]*}', static fn (string $id) => Pages::detail((int) $id));
        \TinyCat\Http\Router::route('GET', '/admin/articles/new', static fn () => Pages::administration(0));
        \TinyCat\Http\Router::route('GET', '/admin/articles/{id:[1-9][0-9]*}', static fn (string $id) => Pages::administration((int) $id));
    }
}
