<?php
declare(strict_types=1);
namespace TinyCat\Blog;

use TinyCat\Database\Connection;
use TinyCat\Database\Transactions;
use TinyCat\Core\Publishing\PostCreation;
use TinyCat\Core\Publishing\Posts;
use TinyCat\Support\Text;

/** Article specialization: Publishing owns identity, author, visibility and preview. */
final class Articles
{
    /** @param array<mixed> $input
     * @param array<mixed> $actor
     * @param array<mixed>|null $file */
    public static function save(array $input, array $actor, int $id = 0, ?array $file = null): int
    {
        self::authorize($actor);
        foreach (['title', 'body', 'status'] as $key) { if (isset($input[$key]) && !is_string($input[$key])) { throw new \InvalidArgumentException('Invalid article.', 422); } }
        $title = trim(Text::strip_html_tags_preserving_text((string) ($input['title'] ?? '')));
        $body = trim(Text::strip_html_tags_preserving_text((string) ($input['body'] ?? '')));
        $status = (string) ($input['status'] ?? 'published');
        self::validateText($title, $body);
        if (!in_array($status, ['published', 'hidden'], true)) { throw new \InvalidArgumentException('Invalid article.', 422); }
        if ($id > 0 && self::find($id, false) === null) { throw new \DomainException('Article not found.', 404); }
        // The preview follows the same text policy and 5.x storage contract as every publication.
        $draft = PostCreation::fromText($body, 'article');
        if ($draft->rejection !== null) { throw new \InvalidArgumentException('Rejected publication.', 422); }
        $remove = filter_var($input['remove_image'] ?? false, FILTER_VALIDATE_BOOLEAN);
        if (($file !== null || $remove) && Connection::get()->inTransaction()) { throw new \LogicException('Media changes require ownership of the commit.'); }
        $candidates = array_slice(\TinyCat\Core\Publishing\Links::status_links_from_text($body), 0, 3);
        $links = $candidates !== [] ? \TinyCat\Core\Publishing\Links::prepareLinks($candidates) : [];
        $image = null;
        if ($file !== null) {
            \TinyCat\Core\Security\RequestLimits::requireAllowed('upload', (int) $actor['id']);
            try { $image = \TinyCat\Core\Publishing\ImageStorage::upload($file); }
            catch (\RuntimeException $error) { throw new \InvalidArgumentException('Invalid article image.', 422, $error); }
        }
        $oldPath = '';
        try {
            $saved = Transactions::run(static function () use ($id, $actor, $title, $body, $status, $draft, $links, $image, $remove, &$oldPath): int {
                if ($id === 0) {
                    $id = PostCreation::create((int) $actor['id'], $draft, $links, $image, kind: 'article');
                    Connection::insert('blog_articles', ['content_id' => $id, 'title' => $title, 'body' => $body]);
                } else {
                    $locked = Connection::one(Connection::lockingSelect("SELECT id FROM content WHERE id = ? AND kind = 'article'"), [$id]);
                    if ($locked === null) { throw new \DomainException('Article not found.', 404); }
                    $existing = \TinyCat\Core\Publishing\Images::status_image_record($id);
                    $oldPath = Posts::update($id, $draft, $links, $image, $remove, $existing);
                    Connection::update('blog_articles', ['title' => $title, 'body' => $body], ['content_id' => $id]);
                }
                Connection::update('content', ['status' => $status], ['id' => $id]);
                return $id;
            });
        } catch (\Throwable $error) {
            if ($image !== null) { \TinyCat\Core\Publishing\ImageStorage::delete((string) $image['path']); }
            throw $error;
        }
        if ($oldPath !== '') { \TinyCat\Core\Publishing\ImageStorage::delete($oldPath); }
        return $saved;
    }

    public static function validateText(string $title, string $body): void
    {
        if ($title === '' || mb_strlen($title) > 200 || $body === '' || strlen($body) > 60000 || !mb_check_encoding($title . $body, 'UTF-8')) { throw new \InvalidArgumentException('Invalid article.', 422); }
        if (\TinyCat\Core\Publishing\Integration::blockedHost($body) !== '' || PostCreation::tagRejection($body) !== null) { throw new \InvalidArgumentException('Rejected publication.', 422); }
    }

    /** @return array<mixed>|null */
    public static function find(int $id, bool $public = true): ?array
    {
        return self::query($public)->where('c.id = ?', $id)->limit(1)->one();
    }

    /** @return array<mixed> */
    public static function page(int $before = 0, string $at = '', bool $public = true): array
    {
        $query = self::query($public, true);
        [$condition, $params] = \TinyCat\Core\Publishing\Archive::cursor($at, $before);
        if ($condition !== '') { $query->where($condition, ...$params); }
        return $query->order('c.published_at DESC, c.id DESC')->limit(21)->all();
    }

    private static function query(bool $public, bool $preview = false): \TinyCat\Database\Query
    {
        $body = $preview ? 'c.body' : 'a.body';
        $query = new \TinyCat\Database\Query('SELECT c.id, c.author_id, c.published_at, c.status, a.title, ' . $body . ' AS body, u.username AS author, i.path AS image_path, i.width AS image_width, i.height AS image_height, i.bytes AS image_bytes FROM content c INNER JOIN blog_articles a ON a.content_id = c.id INNER JOIN users u ON u.id = c.author_id LEFT JOIN content_images i ON i.content_id = c.id');
        $query->where('c.kind = ?', 'article');
        return $public ? \TinyCat\Core\Publishing\Archive::visible($query, 'article')->where('u.status = ?', 'active') : $query;
    }

    /** @param array<mixed> $actor Trusted server identity. */
    public static function delete(int $id, array $actor): void
    {
        self::authorize($actor);
        if (self::find($id, false) === null) { throw new \DomainException('Article not found.', 404); }
        Posts::delete($id);
    }

    /** @param array<mixed> $actor */
    private static function authorize(array $actor): void
    {
        if (($actor['role'] ?? '') !== 'admin' || ($actor['status'] ?? '') !== 'active' || (int) ($actor['id'] ?? 0) < 1) { throw new \DomainException('Forbidden.', 403); }
    }

    /** @param array<mixed> $article
     * @return array<string, mixed> */
    public static function resource(array $article): array
    {
        return ['id' => (int) $article['id'], 'title' => (string) $article['title'], 'body' => (string) $article['body'], 'author' => (string) $article['author'], 'published_at' => (string) $article['published_at'], 'status' => (string) $article['status'], 'url' => '/articles/' . (int) $article['id'], 'image' => ['url' => \TinyCat\Core\Publishing\Images::status_image_url($article), 'author' => (string) $article['author'], 'description' => \TinyCat\Core\Ui\Site::meta_text((string) $article['body'], 120)]] + \TinyCat\Core\Publishing\Resource::content((int) $article['id'], (string) $article['body'], 'article');
    }
}
