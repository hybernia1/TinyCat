<?php
declare(strict_types=1);
namespace TinyCat\Blog;

use TinyCat\Core\Publishing\Interactions;
use TinyCat\Core\Publishing\InteractionTarget;
use TinyCat\Http\Request;
use TinyCat\Http\Response;

/** Blog explicitly opts articles into the framework discussion service. */
final class Discussion
{
    public static function initialize(): void
    {
        \TinyCat\Core\Security\RateLimitPolicy::retainWindows('tinycat.blog', [60]);
        Interactions::provide(new \TinyCat\Core\Publishing\InteractionPolicy('tinycat.blog', 'article', self::resolve(...), self::before(...)));
    }

    /**
     * @param array<string, mixed>|null $actor */
    public static function resolve(int $id, ?array $actor): ?InteractionTarget
    {
        $article = Articles::find($id);
        if ($article === null) { return null; }
        return new InteractionTarget('tinycat.blog', 'article', $id, '/articles/' . $id, true, $actor !== null && ($actor['status'] ?? '') === 'active', \TinyCat\Core\Identity\Roles::isAdmin($actor) || ($actor !== null && (int) $actor['id'] === (int) $article['author_id']));
    }

    /**
     * @param array<string, mixed> $actor
     * @param array<string, mixed> $data */
    public static function before(string $action, InteractionTarget $target, array $actor, array $data): void
    {
        // Shared persistent limiter, independent of Social reputation and cooldowns.
        if (!\TinyCat\Core\Security\RateLimiter::consume('user:' . (int) $actor['id'], 'blog_discussion', 60, 30)) { Response::error(\TinyCat\Support\Localization::t('auth.too_many_requests'), 429, 'rate_limited'); }
    }

    /**
     * @param array<string, mixed>|null $actor
     * @return array<string, mixed> */
    public static function resource(int $id, ?array $actor): array
    {
        $data = Interactions::read('article', $id, $actor);
        $data['target']['api_url'] = '/api/articles/' . $id;
        $data['viewer'] = $actor !== null ? \TinyCat\Core\Identity\Resource::profile($actor) : null;
        return $data;
    }

    public static function register(\TinyCat\Http\Api $api): void
    {
        $base = '/api/articles/{id:[1-9][0-9]*}';
        $api->get($base . '/discussion', static fn (Request $r, array $p): array => self::resource((int) $p['id'], $api->actor()));
        $api->get($base . '/comments/{commentId:[1-9][0-9]*}', static function (Request $r, array $p) use ($api): array {
            $actor = $api->actor(); $target = Interactions::target('article', (int) $p['id'], $actor);
            $comment = \TinyCat\Core\Publishing\Comments::status_comment_item_find((int) $p['commentId'], 'article');
            if ($comment === null || (int) $comment['content_id'] !== $target->id) { Response::error('Not found.', 404, 'comment_not_found'); }
            $item = \TinyCat\Core\Publishing\DiscussionResource::comment($comment, $actor, $target);
            if (!$item['capabilities']['edit'] && !$item['capabilities']['delete']) { Response::error('Forbidden.', 403, 'forbidden'); }
            return ['item' => $item, 'target' => ['id' => $target->id, 'kind' => 'article', 'api_url' => '/api/articles/' . $target->id], 'revisions' => $item['capabilities']['edit'] ? \TinyCat\Core\Publishing\Comments::status_comment_history(\TinyCat\Core\Publishing\Comments::status_comment_find((int) $comment['id']) ?? []) : []];
        }, 'user');
        $save = static function (Request $r, array $p, string $action, ?bool $desired = null) use ($api): array {
            $id = (int) $p['id'];
            $result = Interactions::write('article', $id, $api->actor() ?? [], $action, (int) ($p['commentId'] ?? 0), (string) $r->input('comment', ''), (int) $r->input('parent_id', 0), $desired);
            return self::resource($id, $api->actor()) + ['action' => $action, 'comment_id' => (int) ($result['comment_id'] ?? 0)];
        };
        $api->post($base . '/comments', static fn (Request $r, array $p): array => $save($r, $p, 'comment'));
        $api->patch($base . '/comments/{commentId:[1-9][0-9]*}', static fn (Request $r, array $p): array => $save($r, $p, 'comment_update'));
        $api->delete($base . '/comments/{commentId:[1-9][0-9]*}', static fn (Request $r, array $p): array => $save($r, $p, 'comment_delete'));
        foreach (['put', 'delete'] as $method) {
            $api->$method($base . '/likes/me', static fn (Request $r, array $p): array => $save($r, $p, 'react', $r->method() === 'PUT'));
            $api->$method($base . '/comments/{commentId:[1-9][0-9]*}/likes/me', static fn (Request $r, array $p): array => $save($r, $p, 'comment_like', $r->method() === 'PUT'));
        }
    }
}
