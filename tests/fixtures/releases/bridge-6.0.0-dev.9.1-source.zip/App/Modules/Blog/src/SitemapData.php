<?php
declare(strict_types=1);
namespace TinyCat\Blog;

final class SitemapData
{
    private static function query(): \TinyCat\Database\Query
    {
        return \TinyCat\Core\Publishing\Archive::visible(new \TinyCat\Database\Query('SELECT c.id, c.published_at FROM content c INNER JOIN blog_articles a ON a.content_id = c.id INNER JOIN users u ON u.id = c.author_id'), 'article')->where('u.status = ?', 'active');
    }
    public static function count(): int { return 1 + self::query()->count(); }
    /** @return list<array{url: string, last_modified: ?string}> */
    public static function entries(int $limit, int $offset): array
    {
        $items = $offset === 0 ? [['url' => \TinyCat\Core\Runtime\EntryPages::publicPath('tinycat.blog.home'), 'last_modified' => null]] : [];
        $remaining = $limit - count($items);
        if ($remaining > 0) { foreach (self::query()->order('c.id ASC')->limit($remaining, max(0, $offset - 1))->all() as $r) { $items[] = ['url' => '/articles/' . (int) $r['id'], 'last_modified' => null]; } }
        return $items;
    }
}
