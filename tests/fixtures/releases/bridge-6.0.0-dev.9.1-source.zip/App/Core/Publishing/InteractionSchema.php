<?php
declare(strict_types=1);
namespace TinyCat\Core\Publishing;

/** Shared interactions retain the published tinycat.status history and checksum. */
final class InteractionSchema
{
    /** @return list<string> */
    public static function tables(): array { return ['content_comments', 'content_likes', 'comment_likes']; }

    public static function schema(): \TinyCat\Core\Modules\ModuleSchema
    {
        return new \TinyCat\Core\Modules\ModuleSchema(1, self::tables(), self::install(...), [
            new \TinyCat\Core\Modules\SchemaMigration(1, 'tinycat.status.initial', __DIR__ . '/migrations/interactions/001-initial.php'),
        ]);
    }

    public static function install(\PDO $database): void
    {
        $apply = require __DIR__ . '/migrations/interactions/001-initial.php';
        $apply($database);
    }
}
