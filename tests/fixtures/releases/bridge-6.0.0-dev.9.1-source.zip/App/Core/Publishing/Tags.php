<?php
declare(strict_types=1);

namespace TinyCat\Core\Publishing;

use TinyCat\Core\Text\InlineText;

use Throwable;

class Tags
{

    public static function status_tag_normalize(string $tag): string
    {
        $tag = trim($tag);
        $tag = ltrim($tag, "# \t\n\r\0\x0B");
        $tag = \TinyCat\Support\Text::slug($tag);

        return !ctype_digit($tag) && strlen($tag) <= \TinyCat\Core\Publishing\Tags::status_tag_max_length() ? $tag : '';
    }

    public static function status_tag_max_length(): int
    {
        return 32;
    }

    /**
     * @return array<mixed>
     */
    public static function status_tag_tokens_from_text(string $text): array
    {
        if (!preg_match_all('/(?<![\\p{L}\\p{N}\\p{M}_.@#-])#([\\p{L}\\p{N}][\\p{L}\\p{N}\\p{M}_-]*)/u', InlineText::withoutLinks($text), $matches)) {
            return [];
        }

        return array_values(array_filter(array_map('strval', (array) $matches[1]), static fn (string $tag): bool => preg_match('/^\\p{N}+$/u', $tag) !== 1));
    }

    /**
     * @return array<mixed>
     */
    public static function status_tags_from_text(string $text): array
    {
        $tags = [];

        foreach (\TinyCat\Core\Publishing\Tags::status_tag_tokens_from_text($text) as $item) {
            $tag = \TinyCat\Core\Publishing\Tags::status_tag_normalize((string) $item);

            if ($tag !== '') {
                $tags[$tag] = $tag;
            }
        }

        return array_values($tags);
    }

    public static function normalize_tags_for_storage(string $text): string
    {
        return InlineText::map($text, static fn (string $part): string => (string) preg_replace_callback(
            '/(?<![\\p{L}\\p{N}\\p{M}_.@#-])#([\\p{L}\\p{N}][\\p{L}\\p{N}\\p{M}_-]*)/u',
            static function (array $match): string {
                $tag = \TinyCat\Core\Publishing\Tags::status_tag_normalize((string) $match[1]);

                return $tag !== '' ? '#' . $tag : (string) $match[0];
            },
            $part
        ));
    }

    public static function status_term_id(string $tag): int
    {
        $tag = \TinyCat\Core\Publishing\Tags::status_tag_normalize($tag);

        if ($tag === '') {
            return 0;
        }

        $term = \TinyCat\Database\Queries::db_select('SELECT id, name FROM terms')
            ->where('name = ?', $tag)
            ->limit(1)
            ->one();
        $id = (int) ($term['id'] ?? 0);

        if ($id > 0) {
            if ((string) ($term['name'] ?? '') !== $tag) {
                \TinyCat\Database\Connection::update('terms', ['name' => $tag], ['id' => $id]);
            }

            return $id;
        }

        try {
            return (int) \TinyCat\Database\Connection::insert('terms', ['name' => $tag]);
        } catch (Throwable $exception) {
            if (!\TinyCat\Database\Connection::uniqueViolation($exception)) {
                throw $exception;
            }

            $term = \TinyCat\Database\Queries::db_select('SELECT id, name FROM terms')
                ->where('name = ?', $tag)
                ->limit(1)
                ->one();
            $id = (int) ($term['id'] ?? 0);

            if ($id > 0 && (string) ($term['name'] ?? '') !== $tag) {
                \TinyCat\Database\Connection::update('terms', ['name' => $tag], ['id' => $id]);
            }

            return $id;
        }
    }

    public static function status_term_id_exact(string $tag): int
    {
        $tag = \TinyCat\Core\Publishing\Tags::status_tag_normalize($tag);

        if ($tag === '') {
            return 0;
        }

        foreach (\TinyCat\Database\Queries::db_select('SELECT id, name FROM terms')->where('name = ?', $tag)->all() as $term) {
            if ((string) ($term['name'] ?? '') === $tag) {
                return (int) ($term['id'] ?? 0);
            }
        }

        return 0;
    }

    /**
     * @param array<mixed> $tags
     */
    public static function status_sync_tags(int $contentId, array $tags): void
    {
        if ($contentId < 1) {
            return;
        }

        \TinyCat\Database\Transactions::run(static function () use ($contentId, $tags): void {
            $previousTermIds = \TinyCat\Core\Publishing\Tags::status_term_ids_for_content($contentId);
            \TinyCat\Database\Connection::delete('content_tags', ['content_id' => $contentId]);

            foreach ($tags as $tag) {
                $termId = \TinyCat\Core\Publishing\Tags::status_term_id((string) $tag);

                if ($termId < 1) {
                    continue;
                }

                try {
                    \TinyCat\Database\Connection::insert('content_tags', [
                        'content_id' => $contentId,
                        'term_id' => $termId,
                    ]);
                } catch (Throwable $exception) {
                    if (!\TinyCat\Database\Connection::uniqueViolation($exception)) {
                        throw $exception;
                    }
                    // A duplicate pair can happen under a concurrent attach.
                }
            }

            \TinyCat\Core\Publishing\Tags::status_cleanup_unused_term_ids($previousTermIds);
        });
    }

    /**
     * @return array<mixed>
     */
    public static function status_term_ids_for_content(int $contentId): array
    {
        if ($contentId < 1) {
            return [];
        }

        return \TinyCat\Support\Text::positive_int_ids(array_column(
            \TinyCat\Database\Connection::all('SELECT term_id FROM content_tags WHERE content_id = ?', [$contentId]),
            'term_id'
        ));
    }

    /**
     * @param array<mixed> $termIds
     */
    public static function status_cleanup_unused_term_ids(array $termIds): void
    {
        $termIds = \TinyCat\Support\Text::positive_int_ids($termIds);

        if ($termIds === []) {
            return;
        }

        foreach (array_chunk($termIds, 100) as $chunk) {
            $placeholders = implode(', ', array_fill(0, count($chunk), '?'));
            \TinyCat\Database\Connection::exec(
                'DELETE FROM terms
                    WHERE id IN (' . $placeholders . ')
                        AND NOT EXISTS (
                            SELECT 1
                            FROM content_tags ct
                            WHERE ct.term_id = terms.id
                        )',
                $chunk
            );
        }
    }
}
