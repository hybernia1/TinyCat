<?php
declare(strict_types=1);
namespace TinyCat\Core\Publishing;

use TinyCat\Core\Feeds\FeedParser;
use TinyCat\Core\Feeds\WordPressFeed;
use TinyCat\Core\Text\LinkParser;

use TinyCat\Http\{Client, Session};

/** One execution path for every feed owner, without a dependency on its schema or identity. */
final class FeedPipeline
{
    public function __construct(private FeedSourceStore $store, private FeedTarget $target) {}

    /** @param array<string, mixed> $source
     * @return array<string, mixed> */
    public function run(array $source, bool $force = false, int $schedulerRunId = 0): array
    {
        return Client::withConnectionReuse(function () use ($source, $force, $schedulerRunId): array {
            if (!$this->store->claim($source, $force)) { return ['source_id' => (int) $source['id'], 'status' => 'skipped']; }
            $runId = $this->store->start($source, $schedulerRunId);
            try {
                $items = Session::withoutLock(static fn (): array => FeedParser::fetch((string) $source['feed_url']));
                if ($items === []) { throw new \RuntimeException('Source contains no usable items.'); }
            } catch (\Throwable $error) { return $this->complete($source, $runId, 0, [], [], $error); }
            return $this->import($source, $items, $runId);
        });
    }

    /** No claims, history, publication writes or scheduling changes.
     * @param array<string, mixed> $source
     * @param array<string, mixed> $item */
    public function preview(array $source, array $item): FeedEntry { return $this->target->prepare($source, $item); }

    /** @param array<string, mixed> $source
     * @param list<array<string, mixed>> $items
     * @return array<string, mixed> */
    public function import(array $source, array $items, int $runId = 0): array
    {
        $seen = count($items); $ids = []; $skipped = [];
        try {
            $history = $this->store->history($source, array_map(self::hash(...), $items));
            if (str_contains((string) ($source['post_template'] ?? ''), '{{image}}') && Images::status_images_enabled()) {
                $items = Session::withoutLock(static fn (): array => WordPressFeed::images(array_values(array_filter($items, static fn (array $item): bool => !isset($history[self::hash($item)]))), static fn (string $url): bool => Integration::blockedHost($url) === ''));
            }
            foreach ($items as $item) {
                $hash = self::hash($item);
                if (isset($history[$hash])) { continue; }
                $history[$hash] = true;
                $link = LinkParser::fromRaw((string) ($item['url'] ?? ''));
                if ($this->store->duplicate($source, $link)) { continue; }
                $entry = $this->preview($source, $item);
                $rejection = $entry->rejection ?? $entry->draft->rejection;
                if ($rejection === null && $entry->draft->body === '' && !str_contains((string) ($source['post_template'] ?? ''), '{{image}}')) { $rejection = ['code' => 'status_required', 'params' => []]; }
                if ($rejection !== null) { $skipped[] = ['item_hash' => $hash, 'code' => $rejection['code'], 'params' => $rejection['params']]; continue; }
                $image = Session::withoutLock(static fn (): ?array => FeedImport::prepareImage($source, $item));
                if ($entry->draft->body === '' && $image === null) { $skipped[] = ['item_hash' => $hash, 'code' => 'status_required', 'params' => []]; continue; }
                try {
                    $links = Links::prepareLinks($entry->links, [
                        'url_hash' => (string) ($link['url_hash'] ?? ''), 'title' => (string) ($item['title'] ?? ''),
                        'description' => (string) ($item['description'] ?? ''), 'audio_url' => (string) ($item['audio_url'] ?? ''),
                        'image_urls' => array_values(array_filter((array) ($item['image_urls'] ?? [$item['image_url'] ?? '']), is_string(...))),
                    ]);
                    $ids[] = $this->store->commit($source, $hash, fn (string $at): int => $this->target->publish($source, $entry, $links, $image, $at));
                } catch (\Throwable $error) {
                    if ($image !== null) { ImageStorage::delete((string) $image['path']); }
                    throw $error;
                }
            }
        } catch (\Throwable $error) { return $this->complete($source, $runId, $seen, $ids, $skipped, $error); }
        return $this->complete($source, $runId, $seen, $ids, $skipped);
    }

    /** @param array<string, mixed> $item */
    private static function hash(array $item): string { return hash('sha256', (string) ($item['guid'] ?? '')); }

    /** @param array<string, mixed> $source
     * @param list<int> $ids
     * @param list<array<string, mixed>> $skipped
     * @return array<string, mixed> */
    private function complete(array $source, int $runId, int $seen, array $ids, array $skipped, ?\Throwable $error = null): array
    {
        $status = $error !== null ? 'error' : ($ids !== [] ? 'posted' : 'current');
        $message = $error !== null ? FeedParser::text($error->getMessage(), 500) : '';
        $this->store->finish($source, $runId, $status, $seen, $message);
        return ['source_id' => (int) $source['id'], 'status' => $status, 'content_id' => $ids[0] ?? 0, 'content_ids' => $ids, 'imported_count' => count($ids), 'skipped_items' => $skipped] + ($error !== null ? ['error' => $message] : []);
    }
}
