<?php
declare(strict_types=1);

namespace TinyCat\Core\Publishing;

use PDO;
use RuntimeException;

final class Schema
{
    /** @return list<string> */
    public static function tables(): array { return ['content', 'content_redirects', 'content_images', 'terms', 'content_tags', 'links', 'content_links']; }

    public static function schema(): \TinyCat\Core\Modules\ModuleSchema
    {
        return new \TinyCat\Core\Modules\ModuleSchema(3, self::tables(), self::install(...), [
            new \TinyCat\Core\Modules\SchemaMigration(1, 'tinycat.publishing.initial', __DIR__ . '/migrations/001-initial.php'),
            new \TinyCat\Core\Modules\SchemaMigration(2, 'tinycat.publishing.kinds', __DIR__ . '/migrations/002-kinds.php'),
            new \TinyCat\Core\Modules\SchemaMigration(3, 'tinycat.publishing.interaction-ownership', __DIR__ . '/migrations/003-interaction-ownership.php'),
        ]);
    }

    public static function install(PDO $database): void
    {
        $driver = $database->getAttribute(PDO::ATTR_DRIVER_NAME);
        if (!in_array($driver, ['mysql', 'sqlite'], true)) { throw new RuntimeException('Unsupported publishing database.'); }
        foreach (require __DIR__ . '/install-schema.' . ($driver === 'mysql' ? 'mysql' : 'sqlite') . '.php' as $sql) { $database->exec($sql); }
        if ($driver === 'mysql') { self::ensureTagIndex($database); }
        $upgrade = require __DIR__ . '/migrations/002-kinds.php'; $upgrade($database);
    }

    /** Also repairs an interrupted installation with an existing relation table. */
    public static function ensureTagIndex(PDO $database): void
    {
        if ($database->getAttribute(PDO::ATTR_DRIVER_NAME) !== 'mysql') {
            throw new RuntimeException('The tag archive index requires MySQL or MariaDB.');
        }

        $statement = $database->query('SHOW INDEX FROM content_tags');
        if ($statement === false) { throw new RuntimeException('Unable to inspect the tag archive index.'); }
        $columns = [];
        foreach ($statement->fetchAll(PDO::FETCH_ASSOC) as $index) {
            if ($index['Key_name'] === 'content_tags_term_index') {
                $columns[(int) $index['Seq_in_index']] = (string) $index['Column_name'];
            }
        }
        ksort($columns);
        if (array_values($columns) === ['term_id', 'content_id']) { return; }

        $drop = $columns !== [] ? 'DROP INDEX content_tags_term_index, ' : '';
        if ($database->exec('ALTER TABLE content_tags ' . $drop . 'ADD INDEX content_tags_term_index (term_id, content_id)') === false) {
            throw new RuntimeException('Unable to create the tag archive index.');
        }
    }
}
