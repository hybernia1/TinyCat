<?php
declare(strict_types=1);
namespace TinyCat\Core\Publishing;

interface FeedTarget
{
    /** Pure preparation, shared by preview and execution.
     * @param array<string, mixed> $source
     * @param array<string, mixed> $item */
    public function prepare(array $source, array $item): FeedEntry;
    /** Called inside the source store's transaction; must not download files.
     * @param array<string, mixed> $source
     * @param list<array<mixed>> $links
     * @param array<mixed>|null $image */
    public function publish(array $source, FeedEntry $entry, array $links, ?array $image, string $publishedAt): int;
}
