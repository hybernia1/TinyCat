<?php
declare(strict_types=1);
return require __DIR__ . '/migrations/v1/sqlite.php';
