<?php
declare(strict_types=1);

namespace TinyCat\Core\Publishing;

use TinyCat\Core\Links\Audio;
use TinyCat\Core\Links\Providers;
use TinyCat\Core\Text\LinkParser;
use TinyCat\Core\Text\PostText;

use GdImage;
use RuntimeException;
use Throwable;

class Links
{
    private const METADATA_FAILURE_TTL = 300;

    public static function status_link_title_is_placeholder(string $title): bool
    {
        return Providers::titleIsPlaceholder($title);
    }

    public static function status_url_host_key(string $url): string
    {
        $parts = parse_url($url);

        if (!is_array($parts)) {
            return '';
        }

        $host = strtolower(trim((string) ($parts['host'] ?? ''), '[]'));

        if ($host === '') {
            return '';
        }

        return $host . (isset($parts['port']) ? ':' . (int) $parts['port'] : '');
    }

    public static function status_internal_url(string $url): bool
    {
        $url = trim($url);

        if ($url === '' || str_starts_with($url, '//')) {
            return false;
        }

        if (str_starts_with($url, '/')) {
            return true;
        }

        if (!preg_match('~^https?://~i', $url)) {
            return false;
        }

        $currentHost = \TinyCat\Core\Publishing\Links::status_url_host_key(Integration::baseUrl());
        $urlHost = \TinyCat\Core\Publishing\Links::status_url_host_key($url);

        return $currentHost !== '' && $urlHost !== '' && $currentHost === $urlHost;
    }

    public static function status_internal_url_path(string $url): string
    {
        $url = trim($url);

        if ($url === '' || str_starts_with($url, '//')) {
            return '';
        }

        if (str_starts_with($url, '/')) {
            return \TinyCat\Http\Request::current()->path((string) (parse_url($url, PHP_URL_PATH) ?: $url));
        }

        if (!preg_match('~^https?://~i', $url) || !\TinyCat\Core\Publishing\Links::status_internal_url($url)) {
            return '';
        }

        return \TinyCat\Http\Request::current()->path((string) (parse_url($url, PHP_URL_PATH) ?: '/'));
    }

    public static function status_external_url_pattern(): string
    {
        return '~(?<![@\p{L}\p{N}_])(?:https?://|www\.)[^\s<>"\']+~iu';
    }

    public static function status_strip_external_urls(string $text): string
    {
        if ($text === '') {
            return '';
        }

        $text = (string) preg_replace_callback(\TinyCat\Core\Publishing\Links::status_external_url_pattern(), static function (array $match): string {
            [$url, $tail] = \TinyCat\Core\Text\LinkParser::splitTail((string) ($match[0] ?? ''));

            if (\TinyCat\Core\Publishing\Links::status_internal_url($url)) {
                return $url . $tail;
            }

            return $tail;
        }, $text);

        $text = (string) preg_replace('/[ \t]{2,}/', ' ', $text);
        $text = (string) preg_replace('/\s+([.,;:!?])/u', '$1', $text);
        $text = (string) preg_replace('/[ \t]+\R/u', "\n", $text);
        $text = (string) preg_replace('/\R[ \t]+/u', "\n", $text);
        $text = (string) preg_replace('/\R{3,}/u', "\n\n", $text);

        return trim($text);
    }

    /**
     * @return list<array<mixed>>
     */
    public static function status_links_from_text(string $text): array
    {
        return array_values(array_filter(
            \TinyCat\Core\Text\LinkParser::extract($text),
            static fn (array $link): bool => !\TinyCat\Core\Publishing\Links::status_link_is_internal($link)
        ));
    }

    /** @param array<mixed>|string $link */
    public static function status_link_is_internal(array|string $link): bool
    {
        if (is_array($link)) {
            foreach (['normalized_url'] as $key) {
                $url = trim((string) ($link[$key] ?? ''));

                if ($url !== '' && \TinyCat\Core\Publishing\Links::status_internal_url($url)) {
                    return true;
                }
            }

            return false;
        }

        $url = trim($link);

        return $url !== '' && \TinyCat\Core\Publishing\Links::status_internal_url($url);
    }

    public static function status_link_metadata_ttl(): int
    {
        return 86400;
    }

    /**
     * @param array<mixed> $links
     * @return array<mixed>
     */
    public static function status_link_metadata_cache(array $links): array
    {
        $hashes = [];

        foreach ($links as $link) {
            $link = (array) $link;
            $hash = (string) ($link['url_hash'] ?? '');

            if ($hash !== '') {
                $hashes[$hash] = $hash;
            }
        }

        if ($hashes === []) {
            return [];
        }

        $cached = [];

        try {
            foreach (\TinyCat\Database\Queries::db_select('SELECT * FROM links')
                ->whereIn('url_hash', array_values($hashes))
                ->order('updated_at DESC, id DESC')
                ->all() as $row) {
                $hash = (string) ($row['url_hash'] ?? '');

                if ($hash !== '' && !isset($cached[$hash])) {
                    $cached[$hash] = $row;
                }
            }
        } catch (Throwable) {
            return [];
        }

        return $cached;
    }

    /**
     * @param array<mixed> $link
     * @return array<mixed>
     */
    public static function status_link_data(array $link): array
    {
        $canonical = LinkParser::fromRaw((string) ($link['normalized_url'] ?? ''));
        if ($canonical === null) { return []; }
        $normalizedUrl = $canonical['normalized_url'];
        $hash = $canonical['url_hash'];
        $link = array_replace($link, ['normalized_url' => $normalizedUrl, 'url_hash' => $hash]);

        $taxonomy = Providers::taxonomy($link);
        return [
            'normalized_url' => $normalizedUrl,
            'url_hash' => $hash,
            'provider' => \TinyCat\Support\Text::plain_text_limit($taxonomy['provider'], 40),
            'link_type' => $taxonomy['link_type'],
            'title' => \TinyCat\Support\Text::plain_text_limit((string) ($link['title'] ?? ''), 255),
            'description' => \TinyCat\Support\Text::plain_text_limit(PostText::normalize((string) ($link['description'] ?? '')), 500),
            'image_url' => Providers::youtubeThumbnails($normalizedUrl) !== [] ? '' : \TinyCat\Support\Text::plain_text_limit((string) ($link['image_url'] ?? ''), 2048),
            'video_id' => \TinyCat\Support\Text::plain_text_limit((string) ($link['video_id'] ?? ''), 80),
            'audio_url' => \TinyCat\Support\Text::plain_text_limit((string) ($link['audio_url'] ?? ''), 2048),
            'updated_at' => (string) ($link['_metadata_updated_at'] ?? \TinyCat\Support\Dates::dateDb()),
        ];
    }

    /**
     * @return array<mixed>|null
     */
    public static function status_link_find_by_hash(string $hash): ?array
    {
        $hash = \TinyCat\Support\Text::plain_text_limit($hash, 64);

        if ($hash === '') {
            return null;
        }

        return \TinyCat\Database\Queries::db_select('SELECT * FROM links')
            ->where('url_hash = ?', $hash)
            ->limit(1)
            ->one();
    }

    /**
     * @param array<mixed> $link
     */
    public static function status_link_upsert(array $link): int
    {
        $data = \TinyCat\Core\Publishing\Links::status_link_data($link);

        if ($data === []) {
            return 0;
        }

        $existing = \TinyCat\Core\Publishing\Links::status_link_find_by_hash((string) $data['url_hash']);

        if ($existing === null) {
            try {
                $id = \TinyCat\Database\Connection::insert('links', $data + ['created_at' => \TinyCat\Support\Dates::dateDb()]);

                return max(0, (int) $id);
            } catch (Throwable $exception) {
                if (!\TinyCat\Database\Connection::uniqueViolation($exception)) {
                    throw $exception;
                }

                $existing = \TinyCat\Core\Publishing\Links::status_link_find_by_hash((string) $data['url_hash']);
            }
        }

        $id = (int) ($existing['id'] ?? 0);

        if ($id > 0) {
            \TinyCat\Database\Connection::update('links', $data, ['id' => $id]);
        }

        return $id;
    }

    /**
     * @param array<mixed> $link
     */
    public static function status_link_metadata_fresh(?array $link): bool
    {
        if ($link === null || Providers::needsMetadataRefresh($link)) {
            return false;
        }

        if (!\TinyCat\Core\Publishing\Links::status_link_metadata_has_content($link)) {
            return false;
        }

        $updatedAt = strtotime((string) ($link['updated_at'] ?? ''));

        return $updatedAt > 0 && $updatedAt >= time() - \TinyCat\Core\Publishing\Links::status_link_metadata_ttl();
    }

    /**
     * @param array<mixed> $link
     */
    public static function status_link_metadata_has_content(array $link): bool
    {
        $type = (string) ($link['link_type'] ?? 'web');
        $title = trim((string) ($link['title'] ?? ''));
        $description = trim((string) ($link['description'] ?? ''));
        if ($type === 'audio' && !empty($link['audio_url'])) { return true; }

        if (Providers::googleMap((string) ($link['normalized_url'] ?? '')) !== null) { return $title !== ''; }

        if ($type === 'video') {
            return $title !== '' && !Providers::titleIsPlaceholder($title);
        }

        $fallback = \TinyCat\Core\Text\LinkParser::fromRaw((string) ($link['normalized_url'] ?? ''));
        $fallbackTitle = trim((string) ($fallback['title'] ?? ''));
        $fallbackDescription = trim((string) ($fallback['description'] ?? ''));
        $hasTitle = $title !== '' && ($fallbackTitle === '' || strcasecmp($title, $fallbackTitle) !== 0);
        $hasDescription = $description !== '' && ($fallbackDescription === '' || strcasecmp($description, $fallbackDescription) !== 0);

        return $hasTitle || $hasDescription || trim((string) ($link['image_url'] ?? '')) !== '';
    }

    /**
     * @param array<mixed> $link
     * @param array<mixed> $cached
     * @return array<mixed>
     */
    public static function status_link_apply_cached_metadata(array $link, array $cached, bool $preserveTimestamp): array
    {
        foreach (['provider', 'link_type', 'title', 'description', 'image_url', 'video_id', 'audio_url'] as $key) {
            $value = (string) ($cached[$key] ?? '');

            if ($value !== '') {
                $link[$key] = $value;
            }
        }

        $updatedAt = (string) ($cached['updated_at'] ?? '');
        $link['_metadata_updated_at'] = $preserveTimestamp && $updatedAt !== '' ? $updatedAt : \TinyCat\Support\Dates::dateDb();

        return $link;
    }

    public static function status_link_image_cache(string $imageUrl, string $variant = 'card'): string
    {
        $imageUrl = trim($imageUrl);
        if ($imageUrl === '' || !extension_loaded('gd') || !function_exists('imagewebp')) {
            return '';
        }
        if (str_starts_with($imageUrl, '/uploads/links/')) {
            if (!self::status_link_image_exists($imageUrl)) { return ''; }
            @touch(\TinyCat\Support\Paths::basePath(ltrim($imageUrl, '/')));
            return $imageUrl;
        }
        if (!\TinyCat\Core\Links\Metadata::isSafeRemoteUrl($imageUrl)) {
            return '';
        }

        if (!in_array($variant, ['card', 'social', 'video', 'reel'], true)) { throw new \InvalidArgumentException('Unknown link image variant.'); }
        $subfolder = date('Y/m');
        $filename = substr(hash('sha256', $variant === 'card' ? $imageUrl : $imageUrl . "\0" . $variant), 0, 40) . '.webp';
        $directory = \TinyCat\Support\Paths::basePath('uploads/links/' . $subfolder);
        $target = $directory . DIRECTORY_SEPARATOR . $filename;
        $localUrl = '/uploads/links/' . $subfolder . '/' . $filename;

        if (is_file($target)) {
            @touch($target);
            return $localUrl;
        }

        $response = \TinyCat\Core\Links\Metadata::fetchImage($imageUrl);
        $body = (string) ($response['body'] ?? '');
        $info = $body !== '' && function_exists('getimagesizefromstring') ? @getimagesizefromstring($body) : false;
        $allowedMimes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $width = is_array($info) ? (int) $info[0] : 0;
        $height = is_array($info) ? (int) $info[1] : 0;
        $mime = is_array($info) ? strtolower((string) $info['mime']) : '';

        if (
            $response === null
            || !in_array($mime, $allowedMimes, true)
            || $width < 1
            || $height < 1
            || $width > 8192
            || $height > 8192
            || $height > intdiv(20_000_000, $width)
        ) {
            return '';
        }

        $source = @imagecreatefromstring($body);
        if (!$source instanceof GdImage) {
            return '';
        }

        $targetWidth = 184;
        $targetHeight = 172;
        $targetRatio = $targetWidth / $targetHeight;
        $sourceRatio = $width / $height;
        $cropWidth = $width;
        $cropHeight = $height;
        $sourceX = 0;
        $sourceY = 0;

        if ($sourceRatio > $targetRatio) {
            $cropWidth = max(1, (int) round($height * $targetRatio));
            $sourceX = (int) floor(($width - $cropWidth) / 2);
        } elseif ($sourceRatio < $targetRatio) {
            $cropHeight = max(1, (int) round($width / $targetRatio));
            $sourceY = (int) floor(($height - $cropHeight) / 2);
        }

        if ($variant !== 'card') {
            [$maxWidth, $maxHeight] = match ($variant) { 'social' => [800, 600], 'reel' => [540, 960], default => [960, 540] };
            $scale = min(1, $maxWidth / $width, $maxHeight / $height);
            $targetWidth = max(1, (int) round($width * $scale));
            $targetHeight = max(1, (int) round($height * $scale));
            $sourceX = $sourceY = 0;
            $cropWidth = $width;
            $cropHeight = $height;
        }

        $canvas = \TinyCat\Core\Security\Images::image_resample($source, $targetWidth, $targetHeight, $sourceX, $sourceY, $cropWidth, $cropHeight);
        imagedestroy($source);

        if (!\TinyCat\Support\Storage::ensureDirectory($directory)) {
            imagedestroy($canvas);
            return '';
        }

        try {
            \TinyCat\Core\Security\Images::image_write_webp($canvas, $target, [$variant === 'card' ? 62 : 78], keepExisting: true);
            return $localUrl;
        } catch (RuntimeException) {
            return '';
        } finally {
            imagedestroy($canvas);
        }
    }

    /** @return array{changed: int, has_more: bool} */
    public static function cleanupOrphanImages(int $limit, string $relativeDirectory = ''): array
    {
        if ($relativeDirectory !== '' && preg_match('~^[0-9]{4}/[0-9]{2}$~D', $relativeDirectory) !== 1) {
            throw new \InvalidArgumentException('Invalid link image cleanup directory.');
        }
        $base = \TinyCat\Support\Paths::basePath('uploads/links');
        $directory = $base . ($relativeDirectory !== '' ? '/' . $relativeDirectory : '');
        $resolvedBase = realpath($base);
        $resolvedDirectory = realpath($directory);
        if ($resolvedBase === false || $resolvedDirectory === false) { return ['changed' => 0, 'has_more' => false]; }
        if ($resolvedDirectory !== $resolvedBase && !str_starts_with($resolvedDirectory, $resolvedBase . DIRECTORY_SEPARATOR)) {
            throw new \RuntimeException('Link image directory escapes upload storage.');
        }
        return \TinyCat\Support\FileSweep::run($directory, $limit, static function (array $files) use ($base): array {
            $paths = [];
            foreach ($files as $file) {
                $relative = str_replace('\\', '/', substr($file->getPathname(), strlen($base) + 1));
                if ($file->getMTime() <= time() - 3600 && preg_match('~^[0-9]{4}/[0-9]{2}/[a-f0-9]{40}\.webp$~D', $relative) === 1) {
                    $paths['/uploads/links/' . $relative] = $file->getPathname();
                }
            }
            $stored = [];
            foreach (array_chunk(array_keys($paths), 100) as $chunk) {
                $rows = \TinyCat\Database\Connection::all('SELECT image_url FROM links WHERE image_url IN (' . implode(', ', array_fill(0, count($chunk), '?')) . ')', $chunk);
                foreach ($rows as $row) { $stored[(string) $row['image_url']] = true; }
            }
            $changed = 0;
            foreach ($paths as $url => $path) {
                clearstatcache(true, $path);
                $modified = @filemtime($path);
                if (!isset($stored[$url]) && $modified !== false && $modified <= time() - 3600 && \TinyCat\Support\FileSweep::remove($path)) { $changed++; }
            }
            return ['changed' => $changed, 'has_more' => false];
        });
    }

    public static function status_link_image_exists(string $url): bool
    {
        if (!str_starts_with($url, '/uploads/links/')) { return false; }
        $relative = str_replace('\\', '/', trim(substr($url, strlen('/uploads/links/')), '/'));
        if (!preg_match('~^[0-9]{4}/[0-9]{2}/[a-f0-9]{40}\.webp$~', $relative) || str_contains($relative, '..')) {
            return false;
        }

        return is_file(\TinyCat\Support\Paths::basePath('uploads/links/' . $relative));
    }

    /**
     * @param array<mixed> $link
     * @param array<mixed> $cached
     * @return array<mixed>
     * @param array{url_hash: string, title: string, description: string, image_urls: list<string>, audio_url?: string}|null $source
     */
    public static function status_link_prepare_metadata(array $link, ?array $cached, bool $localizeImage = false, ?array $source = null): array
    {
        $failureKey = 'link-metadata-failure-v1-' . hash('sha256', (string) ($link['normalized_url'] ?? ''));
        $fromSource = $source !== null && $source['title'] !== '';
        if ($fromSource) {
            $prepared = array_replace($link, ['title' => $source['title'], 'description' => $source['description'], '_metadata_updated_at' => \TinyCat\Support\Dates::dateDb()]);
        } elseif ($cached !== null && self::status_link_metadata_fresh($cached)) {
            $prepared = self::status_link_apply_cached_metadata($link, $cached, true);
        } elseif (\TinyCat\Support\Cache::get($failureKey, self::METADATA_FAILURE_TTL) === true) {
            $prepared = $cached !== null ? self::status_link_apply_cached_metadata($link, $cached, true) : $link;
            // A failed attempt must not make old metadata fresh for another day.
            $prepared['_metadata_updated_at'] = (string) ($cached['updated_at'] ?? '1970-01-01 00:00:00');
        } else {
            $prepared = \TinyCat\Core\Links\Metadata::enrich($link);
            if (empty($prepared['_metadata_fetched'])) {
                \TinyCat\Support\Cache::put($failureKey, true, self::METADATA_FAILURE_TTL, 0);
                if ($cached !== null) {
                    $prepared = self::status_link_apply_cached_metadata($prepared, $cached, true);
                }
                $prepared['_metadata_updated_at'] = (string) ($cached['updated_at'] ?? '1970-01-01 00:00:00');
            } else {
                \TinyCat\Support\Cache::forget($failureKey);
                $prepared['_metadata_updated_at'] = \TinyCat\Support\Dates::dateDb();
            }
        }

        if (!empty($source['audio_url'])) {
            $audio = Audio::remote((string) $source['audio_url']);
            if ($audio !== '') { $prepared['audio_url'] = $audio; $prepared['link_type'] = 'audio'; }
        }
        if (Providers::youtubeThumbnails((string) ($prepared['normalized_url'] ?? '')) !== []) {
            $prepared['image_url'] = '';
        } elseif ($localizeImage) {
            $kind = Providers::presentation($prepared)['card_kind'];
            $variant = in_array($kind, ['social', 'video', 'reel'], true) ? $kind : 'card';
            $sources = array_values(array_unique(array_merge($source['image_urls'] ?? [], Providers::imageCandidates($prepared))));
            $prepared['image_url'] = '';
            foreach ($sources as $image) {
                if ($image === '') { continue; }
                $prepared['image_url'] = self::status_link_image_cache($image, $variant);
                if ($prepared['image_url'] !== '') { break; }
            }
            if ($prepared['image_url'] === '' && $fromSource) {
                // Only fetch the article when all images supplied by its feed failed.
                $fallback = self::status_link_prepare_metadata($link, $cached);
                $prepared['image_url'] = self::status_link_image_cache((string) ($fallback['image_url'] ?? ''), $variant);
            }
        }

        if (!empty($prepared['audio_url'])) { $prepared['audio_url'] = Audio::remote((string) $prepared['audio_url']); }
        return $prepared;
    }

    /**
     * @param array<mixed> $links
     * @param array{url_hash: string, title: string, description: string, image_urls: list<string>, audio_url?: string}|null $source
     */
    public static function status_sync_links(int $contentId, array $links, ?array $source = null): void
    {
        if ($contentId < 1) {
            return;
        }

        self::persistLinks($contentId, self::prepareLinks($links, $source));
    }

    /** @param array<mixed> $links
     * @param array{url_hash: string, title: string, description: string, image_urls: list<string>, audio_url?: string}|null $source
     * @return list<array<mixed>>
     */
    public static function prepareLinks(array $links, ?array $source = null): array
    {
        if (\TinyCat\Database\Connection::get()->inTransaction()) {
            throw new \LogicException('Link metadata must be prepared before starting a transaction.');
        }
        $unique = [];
        foreach ($links as $link) {
            $link = (array) $link;
            $canonical = LinkParser::fromRaw((string) ($link['normalized_url'] ?? ''));
            if ($canonical === null) { continue; }
            $unique[$canonical['url_hash']] ??= array_replace($link, ['normalized_url' => $canonical['normalized_url'], 'url_hash' => $canonical['url_hash']]);
        }
        $links = array_values($unique);
        $metadataCache = self::status_link_metadata_cache($links);
        return \TinyCat\Http\Session::withoutLock(static function () use ($links, $metadataCache, $source): array {
            $prepared = [];
            foreach ($links as $link) {
                $link = (array) $link;
                $hash = (string) ($link['url_hash'] ?? '');
                if (\TinyCat\Support\Text::plain_text_limit((string) ($link['normalized_url'] ?? ''), 2048) === '' || $hash === '') { continue; }
                $cacheImage = $source !== null && $source['url_hash'] !== '' && hash_equals($source['url_hash'], $hash);
                $prepared[] = self::status_link_prepare_metadata($link, $metadataCache[$hash] ?? null, true, $cacheImage ? $source : null);
            }
            return $prepared;
        });
    }

    /** @param list<array<mixed>> $links */
    public static function persistLinks(int $contentId, array $links): void
    {
        \TinyCat\Database\Transactions::run(static function () use ($contentId, $links): void {
            $previousLinkIds = self::status_link_ids_for_content($contentId);
            \TinyCat\Database\Connection::delete('content_links', ['content_id' => $contentId]);
            foreach ($links as $link) {
                $linkId = \TinyCat\Core\Publishing\Links::status_link_upsert($link);

                if ($linkId < 1) {
                    continue;
                }

                try {
                    \TinyCat\Database\Connection::insert('content_links', [
                        'content_id' => $contentId,
                        'link_id' => $linkId,
                        'created_at' => \TinyCat\Support\Dates::dateDb(),
                    ]);
                } catch (Throwable $exception) {
                    if (!\TinyCat\Database\Connection::uniqueViolation($exception)) {
                        throw $exception;
                    }
                    // A duplicate URL relation is harmless under a concurrent attach.
                }
            }

            \TinyCat\Core\Publishing\Links::status_cleanup_unused_link_ids($previousLinkIds);
        });
    }

    /**
     * @return array<mixed>
     */
    public static function status_link_ids_for_content(int $contentId): array
    {
        if ($contentId < 1) {
            return [];
        }

        return \TinyCat\Support\Text::positive_int_ids(array_column(
            \TinyCat\Database\Connection::all('SELECT link_id FROM content_links WHERE content_id = ?', [$contentId]),
            'link_id'
        ));
    }

    /**
     * @param array<mixed> $linkIds
     */
    public static function status_cleanup_unused_link_ids(array $linkIds): void
    {
        $linkIds = \TinyCat\Support\Text::positive_int_ids($linkIds);

        if ($linkIds === []) {
            return;
        }

        foreach (array_chunk($linkIds, 100) as $chunk) {
            $placeholders = implode(', ', array_fill(0, count($chunk), '?'));

            try {
                \TinyCat\Database\Connection::exec(
                    'DELETE FROM links
                        WHERE id IN (' . $placeholders . ')
                            AND NOT EXISTS (
                                SELECT 1
                                FROM content_links cl
                                WHERE cl.link_id = links.id
                            )',
                    $chunk
                );
            } catch (Throwable) {
                // Link cleanup is opportunistic and must not block saving a post.
            }
        }
    }

    /**
     * @param array<mixed> $contentIds
     * @return array<mixed>
     */
    public static function status_links_cache(array $contentIds): array
    {
        static $cache = [];

        $ids = \TinyCat\Support\Text::positive_int_ids($contentIds);

        if ($ids === []) {
            return [];
        }

        $missing = array_values(array_filter($ids, static fn (int $id): bool => !array_key_exists($id, $cache)));

        foreach ($missing as $id) {
            $cache[$id] = [];
        }

        if ($missing !== []) {
            foreach (\TinyCat\Database\Queries::db_select(
                'SELECT cl.content_id,
                        l.id AS link_id,
                        l.normalized_url,
                        l.url_hash,
                        l.provider,
                        l.link_type,
                        l.title,
                        l.description,
                        l.image_url,
                        l.video_id,
                        l.audio_url,
                        l.created_at,
                        l.updated_at
                    FROM content_links cl
                    INNER JOIN links l ON l.id = cl.link_id'
            )
                ->whereIn('cl.content_id', $missing)
                ->order('cl.content_id ASC, l.id ASC')
                ->all() as $row) {
                $contentId = (int) ($row['content_id'] ?? 0);

                if ($contentId > 0) {
                    $cache[$contentId][] = $row;
                }
            }
        }

        $result = [];

        foreach ($ids as $id) {
            $result[$id] = $cache[$id] ?? [];
        }

        return $result;
    }

    /**
     * @return array<mixed>
     */
    public static function status_links_for_content(int $contentId): array
    {
        $links = \TinyCat\Core\Publishing\Links::status_links_cache([$contentId]);

        return $links[$contentId] ?? [];
    }

    /**
     * @param array<mixed> $link
     */
    public static function status_link_display_url(array $link): string
    {
        $url = (string) ($link['normalized_url'] ?? '');
        $parts = parse_url($url);

        if (!is_array($parts)) {
            return $url;
        }

        $host = strtolower((string) ($parts['host'] ?? ''));
        $path = (string) ($parts['path'] ?? '');

        return trim($host . ($path !== '/' ? $path : ''));
    }

    public static function status_video_embed_allowed(string $url): bool
    {
        return Providers::embedAllowed($url);
    }

    /**
     * @param array<mixed> $link
     */
    public static function status_video_embed_url(array $link): string
    {
        return Providers::embedUrl($link);
    }

    /**
     * @param array<mixed> $link
     * @return array<mixed>
     */
    public static function status_video_thumbnail_sources(array $link): array
    {
        $youtube = Providers::youtubeThumbnails((string) ($link['normalized_url'] ?? ''));
        if ($youtube !== []) { return ['webp' => '', 'fallback' => $youtube['desktop'], 'mobile' => $youtube['mobile']]; }
        $image = (string) ($link['image_url'] ?? '');
        return ['webp' => '', 'fallback' => self::status_link_image_exists($image) ? $image : '', 'mobile' => ''];
    }
}
