<?php
declare(strict_types=1);
namespace TinyCat\Core\Publishing;

use TinyCat\Core\Text\LinkParser;

/** Resolve only an authorized owner's text and attachments; never arbitrary input URLs. */
final class Outbound
{
    /** @param \Closure(): array<mixed>|null $attachments
     * @return array{url: string, original_url: string}|null */
    public static function resolve(string $hash, string $body, ?\Closure $attachments = null): ?array
    {
        if (preg_match('/^[a-f0-9]{64}$/D', $hash) !== 1) { return null; }
        preg_match_all(LinkParser::pattern(), $body, $matches);
        foreach ($matches[0] as $raw) {
            [$raw] = LinkParser::splitTail($raw); $link = LinkParser::fromRaw($raw);
            if ($link !== null && hash_equals((string) $link['url_hash'], $hash)) { return self::destination($raw); }
        }
        foreach ($attachments !== null ? $attachments() : [] as $link) {
            $parsed = LinkParser::fromRaw((string) ($link['normalized_url'] ?? ''));
            if ($parsed !== null && (hash_equals((string) $parsed['url_hash'], $hash) || hash_equals((string) ($link['url_hash'] ?? ''), $hash))) { return self::destination((string) $link['normalized_url']); }
        }
        return null;
    }
    /** @param array{url: string, original_url: string}|null $link
     * @return array{url: string, original_url: string} */
    public static function response(\TinyCat\Http\Request $request, ?array $link): array
    {
        header('Cache-Control: private, no-store'); header('Vary: Accept'); header('X-Robots-Tag: noindex, nofollow');
        if ($link === null) { \TinyCat\Http\Response::error('Content link not found.', 404, 'content_link_not_found'); }
        if ($request->input('navigate') === '1' && !$request->wantsJson() && str_contains(strtolower((string) $request->header('Accept')), 'text/html')) { header('Referrer-Policy: no-referrer'); header('Location: ' . $link['url'], true, 302); exit; }
        return $link;
    }
    /** @return array{url: string, original_url: string}|null */
    public static function destination(string $raw): ?array
    {
        if (LinkParser::fromRaw($raw) === null || Links::status_internal_url($raw)) { return null; }
        $original = preg_match('~^https?://~i', $raw) === 1 ? $raw : 'https://' . $raw;
        return ['url' => self::tagged($original), 'original_url' => $original];
    }

    public static function tagged(string $url): string
    {
        if (!(bool) Integration::option('content_links.utm.enabled', true)) { return $url; }
        $source = trim((string) Integration::option('content_links.utm.source', ''));
        if ($source === '') { $source = (string) parse_url((string) Integration::option('app.url', ''), PHP_URL_HOST); }
        if ($source === '') { return $url; }
        $values = ['utm_source' => $source, 'utm_medium' => (string) Integration::option('content_links.utm.medium', 'referral'), 'utm_campaign' => (string) Integration::option('content_links.utm.campaign', '')];
        $parts = explode('#', $url, 2);
        $query = (string) parse_url($parts[0], PHP_URL_QUERY);
        $present = [];
        foreach (explode('&', $query) as $parameter) { $present[strtolower(urldecode(explode('=', $parameter, 2)[0]))] = true; }
        $extra = [];
        foreach ($values as $key => $value) { if ($value !== '' && !isset($present[$key])) { $extra[$key] = $value; } }
        if ($extra === []) { return $url; }
        $separator = str_contains($parts[0], '?') ? (str_ends_with($parts[0], '?') || str_ends_with($parts[0], '&') ? '' : '&') : '?';
        return $parts[0] . $separator . http_build_query($extra, '', '&', PHP_QUERY_RFC3986) . (isset($parts[1]) ? '#' . $parts[1] : '');
    }
}
