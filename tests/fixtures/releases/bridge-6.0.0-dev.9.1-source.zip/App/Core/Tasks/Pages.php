<?php
declare(strict_types=1);
namespace TinyCat\Core\Tasks;
use TinyCat\Core\Tasks\Tasks;

use TinyCat\Http\Request;
use TinyCat\Core\Ui\Page as Layout;
use TinyCat\Support\LocalUrls;
use TinyCat\Support\Localization;
use TinyCat\Support\Paths;
use TinyCat\Support\View;
use TinyCat\Core\Identity\Access;

/** HTTP authorization, actions and prepared page composition. */
final class Pages
{
    public static function listing(): void
    {
        Access::require_admin();
        $title = Localization::t('cron.list_title');
        $data = Administration::payload();
        $content = '<div id="scheduler-list">' . \TinyCat\Support\Components::render('scheduler/list', $data + ['state' => $data]) . '</div>';
        Layout::render(['title' => $title, 'current' => '/admin/cron/list'], $content);
    }

    public static function administration(): void
    {
        Access::require_admin();

        if (Request::current()->method() !== 'GET') {
            header('Allow: GET');
            \TinyCat\Core\Runtime\HttpKernel::exception(new \DomainException('Method not allowed.', 405));
            return;
        }

        $cronToken = Tokens::cron_token();
        $cronUrl = LocalUrls::absolute('/api/scheduler/executions');
        $runnerPath = Paths::basePath('scheduled-tasks.php');
        $taskViews = [];

        foreach (Tasks::definitions() as $task => $definition) {
            $admin = $definition['admin'];

            $arguments = [];
            foreach ((array) $definition['options'] as $name => $default) {
                $arguments[] = '--' . str_replace('_', '-', (string) $name) . '=' . (int) $default;
            }

            $taskViews[$task] = [
                ...$admin,
                'cli_arguments' => implode(' ', $arguments),
            ];
        }

        foreach ($taskViews as $task => &$view) {
            $taskUrl = $cronUrl . '?task=' . rawurlencode($task);
            $view['query_url'] = LocalUrls::absolute('/api/scheduler/triggers/' . rawurlencode($task));
            $view['http_command'] = 'curl -fsS -X POST -H "Authorization: Bearer ' . $cronToken . '" "' . $taskUrl . '"';
            $view['cli_command'] = 'php "' . $runnerPath . '" --task=' . $task . ' ' . (string) $view['cli_arguments'];
        }
        unset($view);

        Layout::render([
            'title' => Localization::t('cron.title'),
            'current' => '/admin/cron',
            'actions' => View::render('actions', [], __DIR__ . '/templates'),
        ], \TinyCat\Support\AdminViews::listCard(Localization::t('cron.title'), 'clock', 'scheduler-settings', '', new \TinyCat\Support\Markup(View::render('administration', compact('cronToken', 'cronUrl', 'taskViews'), __DIR__ . '/templates')), primary: true));
    }
}
