<?php
declare(strict_types=1);
namespace TinyCat\Core\Runtime;

/** Published migration names and compatibility entry points; no duplicate implementations. */
final class LegacyNames
{
    public static function canonical(string $class): ?string
    {
        if (str_starts_with($class, 'TinyCat\\Core\\Publishing\\')) {
            $name = substr($class, strlen('TinyCat\\Core\\Publishing\\'));
            $groups = ['LinkParser' => 'Text', 'InlineText' => 'Text', 'PostText' => 'Text', 'Audio' => 'Links', 'Metadata' => 'Links', 'Providers' => 'Links', 'FeedParser' => 'Feeds', 'WordPressFeed' => 'Feeds', 'Rss' => 'Feeds', 'Oembed' => 'Discovery'];
            return isset($groups[$name]) ? 'TinyCat\\Core\\' . $groups[$name] . '\\' . $name : null;
        }
        $special = [
            'TinyCat\\Status\\Comments' => 'TinyCat\\Core\\Publishing\\Comments',
            'TinyCat\\Social\\Posts\\Comments' => 'TinyCat\\Core\\Publishing\\Comments',
            'TinyCat\\Status\\Reactions' => 'TinyCat\\Core\\Publishing\\Reactions',
            'TinyCat\\Social\\Posts\\Reactions' => 'TinyCat\\Core\\Publishing\\Reactions',
            'TinyCat\\Status\\ReadCache' => 'TinyCat\\Core\\Publishing\\ReadCache',
            'TinyCat\\Social\\Posts\\ReadCache' => 'TinyCat\\Core\\Publishing\\ReadCache',
            'TinyCat\\Status\\Segments' => 'TinyCat\\Core\\Publishing\\Segments',
            'TinyCat\\Status\\Images' => 'TinyCat\\Core\\Publishing\\Images',

            'TinyCat\\Site\\LocaleRouting' => 'TinyCat\\Http\\LocaleRouting',
            'TinyCat\\Site\\Metadata' => 'TinyCat\\Core\\Ui\\Metadata',
            'TinyCat\\Site\\Errors' => 'TinyCat\\Core\\Runtime\\Errors',
            'TinyCat\\Status\\AccountLifecycle' => 'TinyCat\\Core\\Publishing\\AccountLifecycle',
            'TinyCat\\Status\\Audio' => 'TinyCat\\Core\\Links\\Audio',
            'TinyCat\\Status\\ImageStorage' => 'TinyCat\\Core\\Publishing\\ImageStorage',
            'TinyCat\\Status\\InlineText' => 'TinyCat\\Core\\Text\\InlineText',
            'TinyCat\\Status\\LinkParser' => 'TinyCat\\Core\\Text\\LinkParser',
            'TinyCat\\Status\\Links' => 'TinyCat\\Core\\Publishing\\Links',
            'TinyCat\\Status\\Metadata' => 'TinyCat\\Core\\Links\\Metadata',
            'TinyCat\\Status\\PostText' => 'TinyCat\\Core\\Text\\PostText',
            'TinyCat\\Status\\Providers' => 'TinyCat\\Core\\Links\\Providers',
            'TinyCat\\Status\\Redirects' => 'TinyCat\\Core\\Publishing\\Redirects',
            'TinyCat\\Users\\Authentication' => 'TinyCat\\Core\\Identity\\Authentication',
            'TinyCat\\Users\\EmailAvailability' => 'TinyCat\\Core\\Identity\\EmailAvailability',
            'TinyCat\\Users\\GeneratedAvatar' => 'TinyCat\\Core\\Identity\\GeneratedAvatar',
            'TinyCat\\Users\\Login' => 'TinyCat\\Core\\Identity\\Login',
            'TinyCat\\Users\\Recovery' => 'TinyCat\\Core\\Identity\\Recovery',

            'TinyCat\\Status\\Schema' => 'TinyCat\\Core\\Publishing\\Schema',
            'TinyCat\\Notifications\\Delivery' => 'TinyCat\\Social\\Posts\\NotificationEvents',
        ];
        if (isset($special[$class])) { return $special[$class]; }
        if (str_starts_with($class, 'TinyCat\\Support\\Updates\\')) {
            $name = substr($class, 24);
            if ($name === 'Module') { $name = 'ServiceProvider'; }
            return 'TinyCat\\Core\\Updates\\' . $name;
        }
        if (str_starts_with($class, 'TinyCat\\Notifications\\')) {
            $name = substr($class, 22);
            if ($name === 'Module') { $name = 'ServiceProvider'; }
            if ($name === 'Inbox') { return 'TinyCat\\Social\\Posts\\LegacyInbox'; }
            return 'TinyCat\\Core\\Notifications\\' . $name;
        }
        if (str_starts_with($class, 'TinyCat\\Installation\\')) {
            $name = substr($class, 21);
            if ($name === 'Module') { $name = 'ServiceProvider'; }
            return 'TinyCat\\Core\\Installation\\' . $name;
        }
        if (str_starts_with($class, 'TinyCat\\Publishing\\')) {
            $name = substr($class, 19);
            if ($name === 'Module') { $name = 'ServiceProvider'; }
            return 'TinyCat\\Core\\Publishing\\' . $name;
        }
        if (str_starts_with($class, 'TinyCat\\Moderation\\')) {
            $name = substr($class, 19);
            if ($name === 'Module') { $name = 'Registration'; }
            return 'TinyCat\\Social\\Moderation\\' . $name;
        }
        if (str_starts_with($class, 'TinyCat\\Scheduler\\')) {
            $name = substr($class, 18);
            if ($name === 'Module') { $name = 'ServiceProvider'; }
            if ($name === 'Schema') { $name = 'LegacySchema'; }
            return 'TinyCat\\Core\\Tasks\\' . $name;
        }
        if (str_starts_with($class, 'TinyCat\\Accounts\\')) {
            $name = substr($class, 17);
            if ($name === 'Module') { $name = 'ServiceProvider'; }
            if ($name === 'ReadModel') { $name = 'LegacyReadModel'; }
            return 'TinyCat\\Core\\Identity\\' . $name;
        }
        if (str_starts_with($class, 'TinyCat\\Security\\')) {
            $name = substr($class, 17);
            if ($name === 'Module') { $name = 'ServiceProvider'; }
            return 'TinyCat\\Core\\Security\\' . $name;
        }
        if (str_starts_with($class, 'TinyCat\\Settings\\')) {
            $name = substr($class, 17);
            if ($name === 'Module') { $name = 'ServiceProvider'; }
            return 'TinyCat\\Core\\Settings\\' . $name;
        }
        if (str_starts_with($class, 'TinyCat\\Updates\\')) {
            $name = substr($class, 16);
            if ($name === 'Module') { $name = 'ServiceProvider'; }
            return 'TinyCat\\Core\\Updates\\' . $name;
        }
        if (str_starts_with($class, 'TinyCat\\Health\\')) {
            $name = substr($class, 15);
            if ($name === 'Module') { $name = 'ServiceProvider'; }
            return 'TinyCat\\Core\\Health\\' . $name;
        }
        if (str_starts_with($class, 'TinyCat\\Status\\')) {
            $name = substr($class, 15);
            if ($name === 'Module') { $name = 'Registration'; }
            return 'TinyCat\\Social\\Posts\\' . $name;
        }
        if (str_starts_with($class, 'TinyCat\\Search\\')) {
            $name = substr($class, 15);
            if ($name === 'Module') { $name = 'Registration'; }
            return 'TinyCat\\Social\\Search\\' . $name;
        }
        if (str_starts_with($class, 'TinyCat\\Users\\')) {
            $name = substr($class, 14);
            if ($name === 'Module') { $name = 'Registration'; }
            return 'TinyCat\\Social\\Profiles\\' . $name;
        }
        if (str_starts_with($class, 'TinyCat\\Mail\\')) {
            $name = substr($class, 13);
            if ($name === 'Module') { $name = 'ServiceProvider'; }
            return 'TinyCat\\Core\\Mail\\' . $name;
        }
        if (str_starts_with($class, 'TinyCat\\Bots\\')) {
            $name = substr($class, 13);
            if ($name === 'Module') { $name = 'Registration'; }
            return 'TinyCat\\Social\\Automation\\' . $name;
        }
        if (str_starts_with($class, 'TinyCat\\Site\\')) {
            $name = substr($class, 13);
            if ($name === 'Module') { $name = 'Registration'; }
            return 'TinyCat\\Social\\Presentation\\' . $name;
        }
        return null;
    }
}
