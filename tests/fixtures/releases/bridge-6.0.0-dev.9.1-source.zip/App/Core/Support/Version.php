<?php
declare(strict_types=1);

namespace TinyCat\Support;

final class Version
{
    public const string MINIMUM_UPDATE = '5.16.0';
    public const string CURRENT = '6.0.0-dev.9.1';
}
